package com.zekelabs.kafka.pojo;

import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadCSV {
	
	public static List<CustomObject> readcsv(String filepath)
	{
		
		String line = "";  
		String splitBy = ",";
		List<CustomObject> customobjectlst = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader(filepath)))   
		{  
		//parsing a CSV file into BufferedReader class constructor  
		  
		while ((line = br.readLine()) != null)   //returns a Boolean value  
		{  
		String[] employee = line.split(splitBy);
		// use comma as separator 
		CustomObject cemp = new CustomObject(employee[0],employee[1],employee[2]);
			
		//System.out.println(cemp.getName()+" "+cemp.getAge());
		customobjectlst.add(cemp);
		}  
		}   
		catch (IOException e)   
		{  
		e.printStackTrace();  
		} 
		
		return customobjectlst;
		}  
		
	}


