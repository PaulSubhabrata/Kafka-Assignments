import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadCSV {
	
	public static List<PassengerRecord> readcsv(String filepath)
	{
		
		String line = "";  
		String splitBy = ",";
		List<PassengerRecord> PassengerRecordList = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader(filepath)))   
		{  
		//parsing a CSV file into BufferedReader class constructor  
		  
		while ((line = br.readLine()) != null)   //returns a Boolean value  
		{  
		String[] pr = line.replace("\"","").split(splitBy);
		// use comma as separator 
		PassengerRecord passenger = new PassengerRecord(pr[0],pr[1],pr[2],pr[3],pr[4],pr[5],pr[6],pr[7],pr[8],pr[9],pr[10],pr[11]);
			
		
		PassengerRecordList.add(passenger);
		}  
		}   
		catch (IOException e)   
		{  
		e.printStackTrace();  
		} 
		
		return PassengerRecordList;
		}  
		
	}



