import java.util.*;
import org.apache.kafka.clients.producer.*;

import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class AvroProducer {

    public static void main(String[] args) throws Exception{

        String topicName = "AvroPassenger";
        String msg;
	String filepath="/home/edyoda/Downloads/titanic-train.csv.txt";

        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092,localhost:9093");        
        props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("schema.registry.url", "http://localhost:8081");

        Producer<String, PassengerRecord> producer = new KafkaProducer <>(props);
        List<PassengerRecord> precords = ReadCSV.readcsv(filepath);;
        try{
           for ( PassengerRecord pr : precords ){
            producer.send(new ProducerRecord<String, PassengerRecord>(topicName,pr.getPassengerId().toString(),pr)).get();
            System.out.println("Publishing"+pr.getPassengerId()+pr.getName());
            System.out.println("Complete");
           }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        }
        finally{
            producer.close();
        }

   }
}
